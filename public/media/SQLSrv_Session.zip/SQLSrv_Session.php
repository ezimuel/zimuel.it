<?php
/**
 * PHP session handler using Microsoft SQL Server
 * with the PHP SQL driver of Microsoft
 * 
 * @see http://www.microsoft.com/sqlserver/2005/en/us/PHP-Driver.aspx
 * @author Enrico Zimuel (enrico@zimuel.it)
 * @version 0.1
 * 
 */
class SQLSrv_Session
{
	const DB_HOST= '';
	const DB_USER= '';
	const DB_PASS= '';
	const DB_NAME= '';
	const DB_SESSION_TABLE='';
    /**
     * Database connection resource
     * 
     * @var resource
     */
    private static $_sess_db;
	/**
	 * Escape string for mssql query
	 * 
	 * @param string $data
	 * @return string
	 */
	private static function sqlsrv_escape($data) {
    	return str_replace("'","''",$data);
	}
    /**
     * Open the session
     * 
     * @return bool
     */
    public static function open() {
    	$connectionInfo= array (
    						'UID' => self::DB_USER,
    						'PWD' => self::DB_PASS,
    						'Database' => self::DB_NAME);
    	self::$_sess_db = sqlsrv_connect(self::DB_HOST, $connectionInfo);
        return self::$_sess_db;
    }
    /**
     * Close the session
     * 
     * @return boolean
     */
    public static function close() {
        return sqlsrv_close(self::$_sess_db);
    }
    /**
     * Read the session
     * 
     * @param string $id
     * @return string 
     */
    public static function read($id) {
        $sql = 'SELECT session_value FROM '. self::DB_SESSION_TABLE .' '.
               'WHERE session_id = \''.self::sqlsrv_escape($id).'\'';       
        $stmt= sqlsrv_query(self::$_sess_db, $sql);
        if (!empty($stmt)) {
        	$row= sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        	return $row['session_value'];
        }
        return '';
    }
    /**
     * Write the session
     * 
     * @param string $id
     * @param string $value
     * @return boolean
     */
    public static function write($id, $value) {
     	$sql= 'UPDATE '.self::DB_SESSION_TABLE.' SET session_value=?, updated_on=? WHERE session_id=?';		  
    	$params = array(self::sqlsrv_escape($value), date("Y-m-d H:i:s"),self::sqlsrv_escape($id));		
		$stmt= sqlsrv_query(self::$_sess_db,$sql,$params);
		if (!empty($stmt)) {
			$result= sqlsrv_rows_affected($stmt);
			if ($result>0) {
				return true;
			}
		}
   		$sql= 'INSERT INTO '.self::DB_SESSION_TABLE.' (session_value, updated_on, session_id) VALUES (?,?,?)';
   		$stmt= sqlsrv_query(self::$_sess_db,$sql,$params);
		if (!empty($stmt)) {
			$result= sqlsrv_rows_affected($stmt);
			if ($result>0) {
				return true;
			}
		}
    	return false;
    }
    /**
     * Destroy the session
     * 
     * @param string $id
     * @return boolean
     */
    public static function destroy($id) {
        $sql = 'DELETE FROM '.self::DB_SESSION_TABLE.' WHERE session_id = ?';
		$params= array(self::sqlsrv_escape($id)); 
        $stmt= sqlsrv_query(self::$_sess_db,$sql,$params);
		return ($stmt!==false);
    }
    /**
     * Garbage Collector
     * 
     * @param integer $max
     * @return boolean
     */
    public static function gc($max) {
        $sql = 'DELETE FROM '.self::DB_SESSION_TABLE.' WHERE updated_on < ?';
		$params= array(array(date("Y-m-d H:i:s",time() - $max))); 
        $stmt= sqlsrv_query(self::$_sess_db,$sql,$params);
		return ($stmt!==false);
    }
}

// to prevent problem of session write after close as PHP 5.0.5 
register_shutdown_function('session_write_close');

ini_set('session.save_handler', 'user');
session_set_save_handler(array('SQLSrv_Session', 'open'),
                         array('SQLSrv_Session', 'close'),
                         array('SQLSrv_Session', 'read'),
                         array('SQLSrv_Session', 'write'),
                         array('SQLSrv_Session', 'destroy'),
                         array('SQLSrv_Session', 'gc'));