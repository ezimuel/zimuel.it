<?php
// display PHP error
error_reporting(E_ALL);
ini_set("display_errors", 1);

// set the probability of garbage collector to 1
ini_set('session.gc_probability', 100);
ini_set('session.gc_divisor', 100);

require_once 'SQLSrv_Session.php';
session_start();

echo 'Storing 50 variables in the session<br> ';
for ($i=1;$i<=50;$i++) {
	$_SESSION["test_$i"]= range(0,$i);
}	

echo 'Reading from session<br>';
echo '<pre>';
for ($i=1;$i<=50;$i++) {
	print_r($_SESSION["test_$i"]);
}
echo '</pre>';

if (isset($_GET['destroy'])) {
	echo 'destroy the session';
	session_destroy();
}	


