<?php
/**
 * i5 Spool class
 * 
 * @version 0.1.1 (2010-02-16)
 * @author Enrico Zimuel (enrico@zimuel.it)
 * @license General Public License GPL
 */
require_once 'Zend/Pdf.php';
require_once 'Zend/Pdf/Page.php';
class i5Spool {
	const MAX_FILE=1024;
	/**
	 * i5 host
	 * @var string
	 */
	private $_host;
	/**
	 * i5 user
	 * @var string
	 */
	private $_user;
	/**
	 * password of the user i5
	 * @var string
	 */
	private $_pass;
	/**
	 * i5 connection resource
	 * @var object
	 */
	private $_conn;
	/**
	 * Construct
	 * 
	 * @param string $host
	 * @param string $user
	 * @param string $pass
	 */
	public function __construct($host='',$user='',$pass='') {
		$this->_host= $host;
		$this->_user= $user;
		$this->_pass= $pass;
		$conn= @i5_connect($host,$user,$pass);
		if (!$conn) {
			throw new Exception("Error on connection to $host with user $user. i5 error: ".i5_error());
		}
		$this->_conn= $conn;
	}
	/**
	 * Destruct
	 */
	public function __destruct() {
		i5_close($this->_conn);
	}
	/**
	 * Get list of spooled files
	 * 
	 * @param string $user
	 * @param integer $num
	 * @return array
	 */
	public function getList($user,$num=self::MAX_FILE) {
		if (empty($user)) {
			return false;		
		}
		$spool = @i5_spool_list(array("username"=>$user),$this->_conn);
		if (!$spool) {
			throw new Exception("Error on getting the spool list for the user $user. i5 error: ".i5_error());
		}
		$list=array();	
		while ($file= i5_spool_list_read($spool) && $num>0) {
			$list[]= $file;
			$num--;
		}
		i5_spool_list_close($spool);
		return $list;
	}
	/**
	 * Convert a spool file to Pdf
	 * 
	 * @param array $spool
	 * @return string
	 */
	public function toPdf($spool,$conf_pdf) {
		if (empty($spool) || !is_array($spool)) {
			return false;
		}	
		$params= array ('SPLFNAME','JOBNAME','USERNAME','JOBNR','SPLFNBR');
		foreach ($params as $param) {	
			if (!array_key_exists($param,$spool)) {
				throw new Exception("You must specify the $param of the spool file!");
			}
		}		
		$data = i5_spool_get_data($spool['SPLFNAME'],$spool['JOBNAME'],
                              	  $spool['USERNAME'],$spool['JOBNBR'],  
	                              $spool['SPLFNBR']);
		if (empty($conf_pdf)) {
			$conf_pdf['page']= Zend_Pdf_Page::SIZE_A4;
			$conf_pdf['font']= Zend_Pdf_Font::FONT_COURIER;
			$conf_pdf['font-size']= 10;
			$conf_pdf['interline']=12;
			$conf_pdf['margin-left']= 20;
			$conf_pdf['margin-top']= 20;
			$conf_pdf['margin-bottom']= 20;
			$conf_pdf['encoding']='utf-8';
		}
		$pdf= new Zend_Pdf();
		$page= new Zend_Pdf_Page($conf_pdf['page']);
		$pdf->pages[] = $page;
		$page->setFont($conf_pdf['font'],$conf_pdf['font-size']);
		$width= $page->getWidth();
		$height= $page->getHeight();
		$lines= explode("\n",$data);
		$y= $height-$conf_pdf['margin-top'];
		foreach ($lines as $line) {
			$page->drawText($line,$conf_pdf['margin-left'],$y,$conf_pdf['encoding']);
			$y-= $conf_pdf['interline'];
			if ((!empty($conf_pdf['page-break']) &&
				 preg_match($conf_pdf['page-break'],$line)) ||
				 $y<$conf_pdf['margin-bottom']) {
					$page= new Zend_Pdf_Page($conf_pdf['page']);
					$page->setFont($conf_pdf['font'],$conf_pdf['font-size']);
					$pdf->pages[] = $page; 
					$y= $height-$conf_pdf['margin-top'];
			}
		}	                              
		return $pdf->render();	                              
	}
}